name = ""
if not name:
    print("show error message, name not found")
else:
    print("Name exists")